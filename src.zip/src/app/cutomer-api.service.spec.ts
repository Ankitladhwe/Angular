import { TestBed, inject } from '@angular/core/testing';

import { CutomerAPIService } from './cutomer-api.service';

describe('CutomerAPIService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CutomerAPIService]
    });
  });

  it('should be created', inject([CutomerAPIService], (service: CutomerAPIService) => {
    expect(service).toBeTruthy();
  }));
});
