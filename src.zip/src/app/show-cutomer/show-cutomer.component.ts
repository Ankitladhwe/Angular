import { Component, OnInit } from '@angular/core';
import {CustInterface} from '../cust-interface';
import {CutomerAPIService} from '../cutomer-api.service';

@Component({
  selector: 'app-show-cutomer',
  templateUrl: './show-cutomer.component.html',
  styleUrls: ['./show-cutomer.component.css']
})
export class ShowCutomerComponent implements OnInit {
  customerlist: CustInterface[];
  constructor(private service: CutomerAPIService) {}

  ngOnInit() {
    this.service.showCustomer().subscribe(data => this.customerlist = data);
  }

}
