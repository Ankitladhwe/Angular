import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowCutomerComponent } from './show-cutomer.component';

describe('ShowCutomerComponent', () => {
  let component: ShowCutomerComponent;
  let fixture: ComponentFixture<ShowCutomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowCutomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowCutomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
