import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {CustInterface} from './cust-interface';

@Injectable({
  providedIn: 'root'
})
export class CutomerAPIService {

  constructor(private http: HttpClient) { }

  showCustomer(): Observable<CustInterface[]> {
    return this.http.get<CustInterface[]>('http://localhost:4000/Cusotmers');
  }
}
