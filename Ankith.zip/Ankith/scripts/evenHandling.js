var app2 = {};

app2.init = function(){
   var button = document.getElementById('ARButton');
   var button2 = document.getElementById('subButton');
    //Function takes two arguments, 
    //second one is annonymous function also known as callback function.
    //app2.text = 'Hi ANkith'
    button.addEventListener('click', function(){
        //getElementById is a Method called with ()
      var headElement = document.getElementById('ARHeading');
        //InnerHtml is a property so no ()
        headElement.innerHTML='JavaScript Classes';
    });

    button2.addEventListener('click',app2.showSubHeading('test'));
}

app2.showSubHeading = function(info){
   return function(){

    var headElement = document.getElementById('subHeading');
    headElement.innerHTML = info;
};
}