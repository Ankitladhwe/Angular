function show() {
    console.log('show fucntion called');
}

var app = {};

app.show = function(){
    console.log('App function called');
}