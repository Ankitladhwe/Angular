var ex = (function(name){

function show() {
    return "Show function " + name;
}

 function display() {
    return "display function " + name;
}
return{
    sh: show,
    dis: display
}

})('Ankith');

var exrefshow = ex;

console.log(exrefshow.sh());
console.log(exrefshow.dis());