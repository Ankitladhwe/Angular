var hospital = require('./Hospital');

var apollo = new hospital(101, "Apollo Hospitals" , 654647);

console.log(apollo.toString());
console.log(apollo.phone);